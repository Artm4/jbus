define({
	status: '${start} - ${end} od ${total} rezultatov',
	gotoFirst: 'Pojdi na prvo stran',
	gotoNext: 'Pojdi na naslednjo stran',
	gotoPrev: 'Pojdi na prejšnjo stran',
	gotoLast: 'Pojdi na zadnjo stran',
	gotoPage: 'Pojdi na stran',
	jumpPage: 'Skoči na stran',
	rowsPerPage: 'Število vrstic na stran'
});
